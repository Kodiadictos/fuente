# -*- coding: utf-8 -*-
from core.libs import *
from core.cloudflare import get_cloudflare_headers

M_HOST = 'http://gnula.nu'

LNG = Languages({
    Languages.es: ['vc', 'castellano', 'es', 'español'],
    Languages.la: ['vl', 'latino', 'la', 'mx'],
    Languages.vos: ['vs', 'vose', 'subtitulado', 'jp'],
    Languages.en: ['ingles', 'en']
})

QLT = Qualities({
    Qualities.scr: ['ts', 'tc-hq', 'ts-hq', 'br-s', 'dvd-s', 'cam', 'web-s'],
    Qualities.hd: ['hd-r', 'hd-tv', 'hdtv', 'micro-hd-720p', 'hd 720p'],
    Qualities.hd_full: ['micro-hd-1080p', 'br-r','hd 1080p'],
    Qualities.rip: ['dvd-r', 'dvdrip', 'hdrip']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        thumb='thumb/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        thumb='thumb/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
        recaptcha=True
    )
    itemlist.append(new_item)

    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="newest_movies",
        label="Novedades",
        url=M_HOST,
        type="item",
        group=True,
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Estrenos",
        url=M_HOST + "/peliculas-de-estreno/lista-de-peliculas-online-parte-1/",
        type="item",
        group=True,
        content_type='movies'))

    itemlist.append(item.clone(
        action="movies",
        label="Recomendadas",
        url=M_HOST + "/peliculas-online/lista-de-peliculas-recomendadas/",
        type="item",
        group=True,
        content_type='movies'))

    itemlist.append(item.clone(
        action="generos_movies",
        label="Géneros",
        url=M_HOST + "/generos/lista-de-generos/",
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        action="movie_search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        content_type='movies'
    ))

    return itemlist


def movie_search(item):
    logger.trace()
    itemlist = list()
    data = httptools.downloadpage('https://cse.google.es/cse.js?sa=G&hpg=1&cx=014793692610101313036:vwtjajbclpq').data
    cse_token = scrapertools.find_single_match(data, '"cse_token": "([^"]+)')

    if not item.url:
        item.url = 'https://cse.google.com/cse/element/v1?' \
                   'rsz=filtered_cse' \
                   '&num=20&' \
                   'hl=es&' \
                   'source=gcsc&' \
                   'gss=.es&' \
                   'cx=014793692610101313036:vwtjajbclpq&' \
                   'q=%s&' \
                   'safe=off&cse_tok=%s&' \
                   'exp=csqr,4231019&callback=google.search.cse.api15976' \
                   '&start=0' % (item.query, cse_token)

    data = downloadpage(item.url, no_decode=True).data
    data = jsontools.load_json(scrapertools.find_single_match(data, "google.search.cse.api15976\((.*?)\);"))

    for result in data['results']:
        if not result['titleNoFormatting'].startswith('Ver'):
            continue
        try:
            title, year = scrapertools.find_single_match(result['titleNoFormatting'],
                                                         'Ver (.*?)(?: \((\d{4})\))? online')
            itemlist.append(item.clone(
                title=title,
                url= scrapertools.find_single_match(result['clicktrackUrl'],'url\?.*?q=([^&]+)'),
                type='movie',
                poster= get_cloudflare_headers(result['richSnippet']['cseImage']['src']),
                content_type='servers',
                action='findvideos',
                year=year
            ))
        except:
            continue

    # Paginador
    next_url = re.sub(r'(start=)(\d+)', lambda m: '%s%s' % (m.group(1), int(m.group(2)) + 20), item.url)
    if next_url and itemlist:
        itemlist.append(item.clone(url=next_url, type='next'))

    return itemlist


def generos_movies(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = '<strong>([^<]+)</strong> \[<a href="([^"]+/generos/lista-de-peliculas-del-genero-[^/]+/)"'

    for genre, url in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            action='movies',
            label=genre,
            url=url,
            content_type='movies'
        ))

    return sorted(itemlist, key=lambda i: i.label)


def newest_movies(item):
    logger.trace()
    itemlist = list()

    data = downloadpage(item.url or M_HOST).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    data = scrapertools.find_single_match(data,
                                          '<strong>NOVEDADES DE PELÍCULAS</strong>(.*?)<div class="widget-content">')

    patron = '<a href="([^"]+)"><img alt="[^"]+" title="(.*?) \((\d{4})\) \[(.*?)\] \[(.*?)\][^"]+" src="([^"]+)" ' \
             'width="98" height="140"'

    for url, title, year, lng, qlt, poster in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            title=title.split('(')[0].strip(),
            url=url,
            poster=get_cloudflare_headers(poster),
            type='movie',
            content_type='servers',
            action='findvideos',
            year=year,
            quality=QLT.get(qlt.lower()),
            lang=[LNG.get(l.lower().strip().split(' ')[0]) for l in lng.split(',')]
        ))

    return itemlist


def movies(item):
    logger.trace()
    itemlist = list()

    if not item.index:
        item.index = 0

    data = downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    #logger.debug(data)

    patron = '<a class="Ntooltip" href="([^"]+)">([^"]+)<span><br /><img src="([^"]+)"></span></a>' \
             '\s+(?:\((\d{4})\)\s+)?\[<span style="color: #33ccff;">[^<]+</span>(.*?)' \
             '\[<span style="color: #ffcc99;">([^<]+)</span>\]'

    results = scrapertools.find_multiple_matches(data, patron)

    for url, title, poster, year, langs, qlt in results[item.index:item.index + 40]:
        itemlist.append(item.clone(
            title=title,
            url=url,
            poster= get_cloudflare_headers(poster),
            type='movie',
            content_type='servers',
            action='findvideos',
            quality=QLT.get(qlt.lower()),
            lang=[LNG.get(l.lower()) for l in scrapertools.find_multiple_matches(langs, '\(([^)]+)\)')],
            year=year
        ))

    # Paginador
    if len(results[item.index + 40:]):
        itemlist.append(item.clone(type='next', index=item.index + 40))
    else:
        current_page = scrapertools.find_single_match(data, '\(parte (\d+)\)</span>: Parte \[')
        if current_page:
            next_url = scrapertools.find_single_match(
                data,
                'Parte.*?\[<a href="([^"]+)">%s</a>\]</p>' % (int(current_page) + 1)
            )
            if next_url:
                itemlist.append(item.clone(url=next_url, type='next'))

    return itemlist


def downloadpage(*args, **kwargs):
    response = httptools.downloadpage(*args, **kwargs)
    if scrapertools.find_single_match(response.data, '<title>DDOS-GUARD</title>'):
        url = kwargs.get('url') or args[0]
        ddg3= response.cookies.get('__ddg3')
        recaptcha_response = platformtools.show_recaptcha(siteurl=url, sitekey=scrapertools.find_single_match(response.data, 'data-sitekey="([^"]+)'))
        httptools.downloadpage('%s/.well-known/ddos-guard/rc?ddg3=%s&id=%s' %('/'.join(url.split('/')[0:3]), ddg3, recaptcha_response))

        response = httptools.downloadpage(*args, **kwargs)

    return response


# Seccion Series
T_HOST = 'https://www.gnula.cc/'

def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="tvshows",
        label="Nuevas series",
        url= T_HOST + 'ver-serie/',
        type="item",
        group=True,
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="newest_episodes",
        label="Nuevos episodios",
        url= T_HOST + 'ver-episode/',
        type="item",
        group=True,
        content_type='episodes'
    ))

    itemlist.append(item.clone(
        action="generos_tvshow",
        label="Géneros",
        type="item",
        group=True,
        url=T_HOST
    ))

    itemlist.append(item.clone(
        action="tv_search",
        label="Buscar",
        query=True,
        type='search',
        group=True,
        url=T_HOST,
        content_type='tvshows'
    ))
    return itemlist


def generos_tvshow(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = '<li id="menu-item-\d+" class="menu-item menu-item-type-taxonomy [^>]+><a href="([^"]+)">([^<]+)</a></li>'

    for url, genre in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            label=genre,
            url=url,
            action='tvshows',
            content_type = 'tvshows'
        ))

    return sorted(itemlist, key=lambda i: i.label)


def tv_search(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(T_HOST + '?s=%s' % item.query).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = '<div class="result-item">.*?<img src="([^"]+)".*?<a href="([^"]+)">([^<]+).*?<span class="year">(\d+)'
    for poster, url, title, year in scrapertools.find_multiple_matches(data, patron):
        title_aux = scrapertools.find_single_match(title, '(.*?)\s*\(\d{4}\)')
        itemlist.append(item.clone(
            title=title_aux if title_aux else title,
            url=url,
            poster=poster,
            year=year,
            type = 'tvshow',
            content_type = 'seasons',
            action = 'seasons'
        ))

    # Paginador
    next_url = scrapertools.find_single_match(data, '''<a class='arrow_pag' href="([^"]+)''')
    if next_url:
        itemlist.append(item.clone(url=next_url, type='next'))

    return itemlist


def tvshows_genre(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = '<li class="[^"]+"><figure><a title="[^"]+" href="([^"]+)"><img class="thumb" src="([^"]+)" ' \
             'alt="[^"]+" /><figcaption>[^<]+</figcaption></a></figure><h3> <a title="[^"]+" href="[^"]+">' \
             '([^"]+)</a> </h3> <p class="date">(\d{4}) \| [^<]+</p><p class="excerpt">([^<]+)</p><p class="generos">' \
             '.*?</p></li>'

    for url, poster, title, year, plot in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            title=title.strip(),
            url=T_HOST + url.replace('/ficha/', '/capitulos/'),
            poster=get_cloudflare_headers(poster),
            action="seasons",
            type='tvshow',
            content_type='seasons',
            year=year,
            plot=plot
        ))

    # Paginador
    next_url = scrapertools.find_single_match(data, '<a href="([^"]+)">></a>')
    if next_url:
        itemlist.append(item.clone(url=T_HOST + next_url, type='next'))

    return itemlist


def tvshows(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url or (T_HOST + 'ver-serie/')).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = '<article id="post-\d+" class="item tvshows"><div class="poster"> <img src="([^"]+)".*?<div class="data"><h3><a href="([^"]+)">([^<]+).*?<span>(\d+)'

    for poster, url, title, year in scrapertools.find_multiple_matches(data, patron):
        title_aux = scrapertools.find_single_match(title, '(.*?)\s*\(\d{4}\)')
        title = title_aux if title_aux else title
        itemlist.append(item.clone(
            title=title,
            tvshowtitle=title,
            year=year,
            url=url,
            poster=poster,
            action="seasons",
            type='tvshow',
            content_type='seasons'
        ))

    # Paginador
    next_url = scrapertools.find_single_match(data, '''<a class='arrow_pag' href="([^"]+)''')
    if next_url:
        itemlist.append(item.clone(url=next_url, type='next'))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    id = scrapertools.find_single_match(data,'var id\s*=\s*(\d+)')

    data = httptools.downloadpage(T_HOST + 'wp-admin/admin-ajax.php', post={'action': 'seasons', 'id': id}).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = "<div class='se-c'><div class='se-q'><span class='se-t.*?>(\d+)</span>"
    for num_season in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            season=int(num_season),
            action="episodes",
            type='season',
            content_type='episodes',
            id=id
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    if not item.id:
        data = httptools.downloadpage(item.url).data
        item.id = scrapertools.find_single_match(data, 'var id\s*=\s*(\d+)')

    data = httptools.downloadpage(T_HOST + 'wp-admin/admin-ajax.php', post={'action': 'seasons', 'id': item.id}).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron= """div class='imagen' data-id='\d+' data-va='\d+'><img src='([^']+)'></div><div class='numerando'>%s\s*-\s*(\d+)</div><div class='episodiotitle'><a href='([^']+)'>([^<]+).*?<div class="lang_ep">(.*?)</div>""" % item.season
    for thumb, episode, url, title, langs in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            title=title,
            action="findvideos",
            url=url,
            poster=thumb,
            episode=int(episode),
            type='episode',
            content_type='servers',
            lang=[LNG.get(l.lower()) for l in scrapertools.find_multiple_matches(langs, '<img title="([^"]+)"')]
        ))

    return itemlist


def newest_episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url or (T_HOST + 'ver-episode/')).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)

    patron = '<img src="([^"]+)"><div class="season_m animation-1"><a href="([^"]+)"><span class="b">([^<]+).*?<span class="c">([^<]+)</span>.*?<div class="langs">(.*?)</div>'
    for thumb, url, season_episode, title, langs in scrapertools.find_multiple_matches(data, patron):
        season, episode = scrapertools.get_season_and_episode(season_episode)
        itemlist.append(item.clone(
            tvshowtitle=title,
            label=title,
            action="findvideos",
            url=url,
            season=int(season),
            episode=int(episode),
            type='episode',
            thumb=thumb,
            content_type='servers',
            lang=[LNG.get(l.lower()) for l in scrapertools.find_multiple_matches(langs, '<img title="([^"]+)"')]
        ))

    # Paginador
    next_url = scrapertools.find_single_match(data, '''<a class='arrow_pag' href="([^"]+)''')
    if next_url:
        itemlist.append(item.clone(url=next_url, type='next'))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = re.sub(r"\n|\r|\t|\s{2}|&nbsp;", "", data)
    #logger.debug(data)

    if item.type == 'episode':
        patron = "<tr id='link-' data='1'><td><a href='([^']+)'[^>]+>([^<]+).*?domain=([^']+).*?class='quality'>([^<]+).*?flags/(.+?)\.png"
        for url, modo, server, qlt, lng in scrapertools.find_multiple_matches(data, patron):
            itemlist.append(item.clone(
                url=url,
                type='server',
                action='play',
                lang=LNG.get(lng.lower()),
                quality=QLT.get(qlt.lower()),
                server=server.split('.')[0].lower().strip(),
                stream=modo.strip() == 'Reproducir'
            ))

        itemlist = servertools.get_servers_from_id(itemlist)
    else:
        if '<em>opción ' in data:
            patron = '<em>opción \d, ([^,]+), ([^<]+)</em></p>(.*?)<div style="clear:both;">'
            for lng, qlt, enlaces, in scrapertools.find_multiple_matches(data, patron):
                for url in scrapertools.find_multiple_matches(enlaces, '(?:src|href)="(http[^"]+)"'):
                    if not url.endswith('/soon'):
                        itemlist.append(item.clone(
                            url=url,
                            type='server',
                            action='play',
                            lang=LNG.get(lng.lower()),
                            quality=QLT.get(qlt.lower())
                        ))
        else:
            patron = '<strong>Ver película online</strong> \[<span style="color: #ff0000;">([^<]+)' \
                     '</span>](.*?)<div style="clear:both;">'
            info, enlaces = scrapertools.find_single_match(data, patron)
            info = info.replace(" ", "").split(',')
            for url in scrapertools.find_multiple_matches(enlaces, '(?:src|href)="(http[^"]+)" (?:target|frameborder)='
                                                                   '"[^"]+"(?! class="broken_link")'):
                if not url.endswith('/soon'):
                    itemlist.append(item.clone(
                        url=url,
                        type='server',
                        action='play',
                        lang=LNG.get(info[1].lower()),
                        quality=QLT.get(info[2].lower())
                    ))

        itemlist = servertools.get_servers_itemlist(itemlist)

    return itemlist

