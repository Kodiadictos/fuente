# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://inkapelis.me'

services = {'PlayVIP': 'googledrive',
            'MePlay': 'netutv',
            'MixDrop': 'mixdrop',
            'Drive': 'googledrive',
            'Descargar': 'mega',
            'GoPlay': 'gounlimited',
            'PlaySTP': 'streamtape',
            'UpStream': 'upstream',
            'UqLoad': 'uqload',
            'Fembed': 'fembed',
            'Stream': 'mystream',
            'EvoPlay': 'evoload'
            }

LNG = Languages({
    Languages.es: ['castellano', 'español'],
    # Languages.en: ['english'],
    Languages.la: ['latino'],
    Languages.vos: ['subtitulado']
})

QLT = Qualities({
    Qualities.rip: ['DVD'],
    Qualities.hd: ['HD'],
    # Qualities.sd: ['dvdfull'],
    # Qualities.hd_full: ['hdfull', 'hd1080'],
    # Qualities.scr: ['screener']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    new_item = item.clone(
        type='label',
        label="Películas",
        category='movie',
        banner='banner/movie.png',
        icon='icon/movie.png',
        poster='poster/movie.png'
    )
    itemlist.append(new_item)
    itemlist.extend(menupeliculas(new_item))

    new_item = item.clone(
        type='label',
        label="Series",
        category='tvshow',
        banner='banner/tvshow.png',
        icon='icon/tvshow.png',
        poster='poster/tvshow.png',
    )
    itemlist.append(new_item)
    itemlist.extend(menuseries(new_item))

    return itemlist


def menupeliculas(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        action="movies",
        label="Novedades",
        url=HOST + '/calidad/hd/',
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="movies",
        label="Castellano",
        url=HOST + '/idioma/castellano/',
        lang=LNG.get('castellano'),
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="movies",
        label="Latino",
        url=HOST + '/idioma/latino/',
        lang=LNG.get('latino'),
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        action="movies",
        label="Subtituladas",
        url=HOST + '/idioma/subtituladas/',
        lang=LNG.get('subtitulado'),
        type="item",
        group=True,
        content_type='movies'
    ))

    itemlist.append(item.clone(
        label='Generos',
        action='generos',
        type="item",
        group=True,
        content_type='items',
        url=HOST
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        query=True,
        content_type='movies',
        type="search",
        group=True
    ))

    return itemlist


def generos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    data = scrapertools.find_single_match(data, r'<ul class="sub-menu"><li id="menu-item-1138"(.*?)</ul>')

    for url, label in scrapertools.find_multiple_matches(data, r'<a href="([^"]+)">([^<]+)</a>'):
        itemlist.append(item.clone(
            action='movies',
            label=label.replace(' / Guerra', ''),
            url=HOST + url,
            content_type='movies'
        ))

    return itemlist


def menuseries(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Nuevos episodios',
        action='list_episodes',
        content_type='episodes',
        url=HOST + '/episodio/',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Series actualizadas',
        action='tvshows',
        content_type='tvshows',
        url=HOST + '/serie/',
        type="item",
        group=True
    ))

    itemlist.append(item.clone(
        label='Buscar',
        action='search',
        query=True,
        content_type='tvshows',
        type="search",
        group=True
    ))

    return itemlist


def movies(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = r'data-src="([^"]+)" alt="[^>]+><div class="rating"><span class="icon-star2"></span>[^<]*</div>' \
             r'<div class="mepo"> <span class="quality">([^<]+)</span></div>.*?<div class="data"><h3>' \
             r'<a href="([^"]+)">([^<]+).*?<span>(\d+)</span>.*?<div class="audio">(.+?)<div class="texto">([^<]+)'

    for poster, qlt, url, title, year, idiomas, plot in scrapertools.find_multiple_matches(data, patron):
        langs = scrapertools.find_multiple_matches(idiomas, '<div class="([^"]+)"')
        poster = poster.replace('/w185/', '/original/')
        itemlist.append(item.clone(
            action='findvideos',
            title=title,
            type='movie',
            year=year,
            plot=plot,
            url=url,
            content_type='servers',
            poster=poster if poster.startswith('http') else 'https:' + poster,
            quality=QLT.get(qlt),
            lang=[LNG.get(y.lower().split()[0]) for y in langs if y != ' '] if not item.lang else item.lang
        ))

    if itemlist:
        next_url = scrapertools.find_multiple_matches(data, """<span class="current">.*?<a href='([^']+)""")
        if next_url:
            itemlist.append(item.clone(url=next_url[-1], type='next'))

    return itemlist


def tvshows(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = r'data-src="([^"]+)".*?<div class="data"><h3><a href="([^"]+)">([^<]+).*?<span>(\d+)</span>.*?' \
             r'<div class="texto">([^<]+)'
    for poster, url, title, year, plot in scrapertools.find_multiple_matches(data, patron):
        poster = poster.replace('/w185/', '/original/')
        itemlist.append(item.clone(
            action='seasons',
            title=title,
            type='tvshow',
            content_type='seasons',
            year=year,
            plot=plot,
            url=url,
            poster=poster if poster.startswith('http') else 'https:' + poster
        ))

    if itemlist:
        next_url = scrapertools.find_multiple_matches(data, """<span class="current">.*?<a href='([^']+)""")
        if next_url:
            itemlist.append(item.clone(url=next_url[-1], type='next'))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    for season, title in scrapertools.find_multiple_matches(
            data,
            r"<span class='se-t[^>]+>(\d+)</span><span class='title'>([^<]+)"):
        itemlist.append(item.clone(
            season=int(season),
            title=title,
            tvshowtitle=item.title,
            action="episodes",
            type='season',
            content_type='episodes'
        ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = "<span class='se-t[^>]+>%s</span>.*?<ul class='episodios'>(.*?)</ul>" % item.season
    temporada = scrapertools.find_single_match(data, patron)
    patron = r"data-src='([^']+)'></div><div class='numerando'>([^<]+)</div>" \
             r"<div class='episodiotitle'><a href='([^']+)'>([^<]+)"

    for thumb, season_and_episode, url, title in scrapertools.find_multiple_matches(temporada, patron):
        num_season, num_episode = scrapertools.get_season_and_episode(season_and_episode.replace(' - ', 'x'))
        thumb = thumb.replace('/w154/', '/original/')
        itemlist.append(item.clone(
            title=title,
            url=url,
            thumb=thumb if thumb.startswith('http') else 'https:' + thumb,
            action="findvideos",
            episode=num_episode,
            type='episode',
            content_type='servers'
        ))

    return itemlist


def list_search(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = r'data-src="([^"]+)".*?<div class="mepo">(.*?)<div class="see"></div></a></div><div class="data">' \
             r'<h3><a href="([^"]+)">([^<]+)</a></h3> <span>(\d+)</span>'

    for poster, mepo, url, title, year in scrapertools.find_multiple_matches(data, patron):
        new_item = item.clone(
            url=url,
            title=title,
            year=year,
            poster=poster if poster.startswith('http') else 'https:' + poster
        )

        if item.content_type == 'movies':
            new_item.action = 'findvideos'
            new_item.content_type = 'servers'
            new_item.type = 'movie'
            new_item.quality = QLT.get(scrapertools.find_single_match(mepo, r'<span class="quality">([^<]+)</span>'))

        else:
            new_item.action = 'seasons'
            new_item.content_type = 'seasons'
            new_item.type = 'tvshow'

        itemlist.append(new_item)

    if itemlist:
        next_url = scrapertools.find_multiple_matches(data, """<span class="current">.*?<a href='([^']+)""")
        if next_url:
            itemlist.append(item.clone(url=next_url[-1], type='next', action='list_search'))

    return itemlist


def list_episodes(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data
    patron = r'data-src="([^"]+)".*?<div class="data"><h3><a href="([^"]+)">([^<]+)</a></h3> ' \
             r'<span>([^/]+).*?<span class="serie">([^<]+)'

    for thumb, url, title, season_and_episode, tvshowtitle in scrapertools.find_multiple_matches(data, patron):
        num_season, num_episode = scrapertools.get_season_and_episode(season_and_episode.replace(' ', ''))
        thumb = thumb.replace('/w154/', '/original/')
        itemlist.append(item.clone(
            tvshowtitle=tvshowtitle,
            url=url,
            thumb=thumb if thumb.startswith('http') else 'https:' + thumb,
            action="findvideos",
            season=num_season,
            episode=num_episode,
            type='episode',
            content_type='servers'
        ))

    if itemlist:
        next_url = scrapertools.find_multiple_matches(data, """<span class="current">.*?<a href='([^']+)""")
        if next_url:
            itemlist.append(item.clone(url=next_url[-1], type='next'))

    return itemlist


def search(item):
    logger.trace()
    if item.content_type == 'movies':
        item.url = HOST + '/pelicula/?s=' + item.query.replace(" ", "+")
    else:
        item.url = HOST + '/serie/?s=' + item.query.replace(" ", "+")
    return list_search(item)


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = httptools.downloadpage(item.url).data

    patron = r"data-post='([^']+)' data-nume='([^']+)'>" \
             r"<span class='title'><noscript><img src='https://inkapelis.me/wp-content/themes/dooplay/assets/img/" \
             r"flags/([^\.]+)"

    servers_data = {}
    for dpost, nume, lng in scrapertools.find_multiple_matches(data, patron):
        if item.category == 'movie' and item.lang and not isinstance(item.lang, list) and item.lang != LNG.get(lng):
            continue
        post = {
            'action': 'doo_player_ajax',
            'post': dpost,
            'nume': nume,
            'type': 'movie' if item.category == 'movie' else 'tv'
        }
        data = httptools.downloadpage('https://inkapelis.me/wp-admin/admin-ajax.php', post).data
        url = scrapertools.find_single_match(data, "src='([^']+)'")
        servers_data[lng] = httptools.downloadpage(url, headers={'Referer': item.url}).data

    for lng in servers_data:
        # Metodo1: Varios idiomas juntos
        if 'IdiomaSet' in servers_data[lng]:
            langs = scrapertools.find_multiple_matches(
                servers_data[lng],
                r"onclick=\"IdiomaSet\(this, '(\d)'\);\".*?/lang/([^.]+)"
            )

            for n, lang in langs:
                if item.category == 'movie' and item.lang and not \
                        isinstance(item.lang, list) and item.lang != LNG.get(lang.lower()):
                    continue

                lng_data = scrapertools.find_single_match(
                    servers_data[lng],
                    r'<div class="Player%s.*?">(.*?)</div>[^<]+</div>' % n
                )
                patron = r"go_to_player\('/([^/]+)/([^&]+).*?'.*?<span class=\"serverx\">([^<]+)</span>"

                for typo, embed, server in scrapertools.find_multiple_matches(lng_data, patron):
                    if typo == 'download':
                        it = play(item.clone(
                            embed=embed,
                            type='server',
                            action='play',
                            stream=False,
                            lang=LNG.get(lang.lower())
                        ))
                        itemlist.extend(servertools.get_servers_itemlist([it]))

                    else:
                        itemlist.append(item.clone(
                            embed=embed,
                            server=services.get(server, server),
                            type='server',
                            action='play',
                            stream=True,
                            lang=LNG.get(lang.lower())
                        ))

        # Metodo2: Cada idioma por serparado
        else:
            patron = r'data-embed="([^"]+)" data-type="([^"]+)"><span class="icon"><span class="symbol">' \
                     r'</span></span> <span class="serverx">([^<]+)'

            for embed, tipo, alias in scrapertools.find_multiple_matches(servers_data[lng], patron):
                itemlist.append(item.clone(
                    action='play',
                    type='server',
                    embed=embed,
                    stream=tipo == 'Embed',
                    lang=LNG.get(lng),
                    alias=alias,
                    server=services.get(alias, alias)
                ))

    return servertools.get_servers_from_id(itemlist)


def play(item):
    logger.trace()

    resp = httptools.downloadpage(
        "https://play.inkapelis.me/playdir/" + item.embed,
        add_referer=True,
        follow_redirects=False
    )
    item.url = resp.headers['location']
    servertools.normalize_url(item)
    return item
