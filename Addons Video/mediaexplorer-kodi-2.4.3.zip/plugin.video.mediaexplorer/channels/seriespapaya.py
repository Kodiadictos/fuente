# -*- coding: utf-8 -*-
from core.libs import *

HOST = 'https://seriespapaya.xyz/'

LNG = Languages({
    Languages.es: ['castellano'],
    Languages.la: ['latino'],
    Languages.vos: ['subtitulado']
})

QLT = Qualities({
    Qualities.hd_full: ['1080-p'],
    Qualities.hd: ['720-p']
})


def mainlist(item):
    logger.trace()
    itemlist = list()

    itemlist.append(item.clone(
        label='Actualizadas',
        action='newest_tvshows',
        url=HOST + 'series-2',
        type="item",
        #group=True,
        content_type='tvshows'
    ))

    itemlist.append(item.clone(
        action="newest_tvshows",
        label="Nuevas series",
        url=HOST + "?s=trfilter&trfilter=1&years%5B%5D=2021&tr_post_type=2",
        type="item",
        category='tvshow',
        content_type='tvshows'
    ))

    """itemlist.append(item.clone(
        action="newest_episodes",
        label="Nuevos episodios",
        url=HOST + 'episodios',
        type="item",
        content_type='episodes'
    ))"""


    # "Buscar"
    itemlist.append(item.clone(
        action="search",
        label="Buscar",
        query=True,
        type='search',
        category='tvshow',
        content_type='tvshows'
    ))

    return itemlist


def newest_tvshows(item):
    logger.trace()
    itemlist = list()

    if not item.url:
        item.url = HOST + 'series-2'

    data = scrapertools.remove_white_spaces(downloadpage(item.url).data)
    patron = 'class="TPost C"><a href="([^"]+)".*?src="([^"]+).*?class="Title">([^<]+)</h3><span class="Year">([^<]+)'
 
    for url, poster, title, year in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            action='seasons',
            label=title,
            tvshowtitle=title,
            title=title,
            url= url,
            year=year,
            poster= poster if poster.startswith('http') else "https:" + poster,
            type='tvshow',
            content_type='seasons'))

    next_page = scrapertools.find_single_match(data, r'<a class="next page-numbers" href="([^"]+)')
    if itemlist and next_page:
        itemlist.append(item.clone(type='next', url=next_page))

    return itemlist


def seasons(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(downloadpage(item.url).data)

    patron = r'<div class="Title AA-Season.*?data-tab="(\d+)">(.*?)<i class(.*?)</tbody>'
    for season, title, episodios in scrapertools.find_multiple_matches(data, patron):
        if '<td>Episodios no disponibles</td>' not in episodios:
            itemlist.append(item.clone(
                action="episodes",
                title = re.sub(r'<.?span>','',title),
                season=int(season),
                type='season',
                content_type='episodes'
            ))

    return itemlist


def episodes(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(downloadpage(item.url).data)
    data = scrapertools.find_single_match(data, r'<div class="Title AA-Season.*?data-tab="%s">.*?<tbody>(.*?)</tbody>' %item.season)

    patron = '<td><span class="Num">(\d+)</span></td>.*?src="([^"]+).*?href="([^"]+)">([^<]*)'
    for num_episode, thumb, url, label in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            #title=item.tvshowtitle,
            title = label,
            thumb=thumb if thumb.startswith('http') else "https:" + thumb,
            url= url,
            action="findvideos",
            episode=int(num_episode),
            type='episode',
            content_type='servers'
        ))

    return itemlist


def findvideos(item):
    logger.trace()
    itemlist = list()

    data = scrapertools.remove_white_spaces(downloadpage(item.url).data)
    patron = '<td><span class="Num">.*?href="([^"]+)" class="Button STPb">([^<]+)</a></td><td><span><.*?>\s*([^<]+)' \
             '</span></td><td><span><img.*?>([^<]+)</span></td><td><span>([^<]+)'

    for url, tipo, server, lang, qlt in scrapertools.find_multiple_matches(data, patron):
        itemlist.append(item.clone(
            url= url,
            server=server.strip().lower(),
            action='play',
            type='server',
            lang=LNG.get(lang.lower()),
            quality=QLT.get(qlt.lower()),
            stream=(tipo == 'Online')
        ))

    return servertools.get_servers_from_id(itemlist)


def play(item):
    logger.trace()
    if item.url.startswith(HOST):
        item.url = httptools.downloadpage(item.url, follow_redirects=False).headers['location']
    servertools.normalize_url(item)

    return item


def search(item):
    logger.trace()
    item.url = HOST + "?s=%s&tr_post_type=2" % item.query.replace(" ", "+")

    return newest_tvshows(item)


def downloadpage(*args, **kwargs):
    resp = httptools.downloadpage(*args, **kwargs)
    decoder = Securi(resp.data)
    if decoder.is_securi:
        kwargs['cookies'] = decoder.get_cookie()
        resp = httptools.downloadpage(*args, **kwargs)

    return resp


class Securi:
    def __init__(self, data):
        import base64
        self.data = data
        value = six.ensure_text(base64.b64decode(scrapertools.find_single_match(data, r"S='([^']+)'")))
        self.value_data = scrapertools.find_single_match(value, r"[^=]+=(.*?);docu")
        self.name_data = scrapertools.find_single_match(value, r'document.cookie=(.*?)\+\s*["\']=')

    @property
    def is_securi(self):
        # TODO: Quiza habra que mejorar la forma de detección
        return "sucuri_cloudproxy_js" in self.data

    @property
    def cookie_name(self):
        return self.decode(self.name_data)

    @property
    def cookie_value(self):
        return self.decode(self.value_data)

    @staticmethod
    def decode(value):
        result = ""

        # TODO: Estas son las operaciones que he visto, si hay mas habria que añadrlas
        for op in value.split('+'):
            if re.compile(r"['|\"]([^'\"]+)['|\"]\.(?:substr|slice)\((\d),\s*(\d)\)").search(op):
                val, s, e = re.compile(r"['|\"]([^'\"]+)['|\"]\.(?:substr|slice)\((\d),\s*(\d)\)").findall(op)[0]
                result += val[int(s): int(s) + int(e)]
            elif re.compile(r"['|\"]([^'\"]+)['|\"]\.charAt\((\d)\)").search(op):
                val, c = re.compile(r"['|\"]([^'\"]+)['|\"]\.charAt\((\d)\)").findall(op)[0]
                result += val[int(c)]
            elif re.compile(r"['|\"]([^'\"]*)['|\"]").search(op):
                val = re.compile(r"['|\"]([^'\"]*)['|\"]").findall(op)[0]
                result += val
            elif re.compile(r"String.fromCharCode\(0x(\d+)\)").search(op):
                val = re.compile(r"String.fromCharCode\(0x(\d+)\)").findall(op)[0]
                result += chr(int(val, 16))
            elif re.compile(r"String.fromCharCode\((\d+)\)").search(op):
                val = re.compile(r"String.fromCharCode\((\d+)\)").findall(op)[0]
                result += chr(int(val))
            else:
                logger.debug(op)
        return result

    def get_cookie(self):
        return {
            self.cookie_name: self.cookie_value
        }
