# -*- coding: utf-8 -*-
import sys
import os

# Añadir path para librerias
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'lib'))