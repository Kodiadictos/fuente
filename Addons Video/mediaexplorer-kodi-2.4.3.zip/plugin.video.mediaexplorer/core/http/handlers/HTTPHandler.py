# -*- coding: utf-8 -*-
import socket

from six.moves import http_client, urllib_request

from core.http.dns import Resolve
from core.libs import *


class HTTPHandler(urllib_request.HTTPHandler):
    """
    HTTPHandler modificado para utilizar la clase HTTPConnection de abajo
    """
    def http_open(self, req):
        return self.do_open(HTTPConnection, req)


class HTTPConnection(http_client.HTTPConnection):
    """
    HTTPConnection modificado para varias cosas:
     - Funcion connect:
        - Se modifica para permitir resolver las url mediante otro servidor DNS
     - Funcion _send_request:
        - Ordena los headers para que cloudflare no se queje
    """
    def connect(self):

        # Resolver mediante dnsresolver usando un servidor DNS personalizado
        if settings.get_setting('dns_mode', __file__) == 1:
            host = Resolve(self.host)
        # El sistema resuelve la url
        else:
            host = self.host

        if isinstance(host, six.string_types):
            self.sock = socket.create_connection((host, self.port), self.timeout, self.source_address)
        else:
            for h in host:
                try:
                    self.sock = socket.create_connection((host, self.port), self.timeout, self.source_address)
                except Exception:
                    if host.index(h) == len(host) - 1:
                        raise
                else:
                    break

        if self._tunnel_host:
            if settings.get_setting('dns_proxy', __file__):  # Resolver DNS Local
                tunnel_host = Resolve(self._tunnel_host)
                if not isinstance(tunnel_host, six.string_types):
                    tunnel_host = tunnel_host[0]
                self._tunnel_host = tunnel_host
            self._tunnel()

    def _send_request(self, method, url, body, headers, *args, **kwargs):
        from collections import OrderedDict
        order = ["Host", 'User-Agent', 'Accept']

        headers = OrderedDict([(k, v) for k, v in sorted(
            list(headers.items()),
            key=lambda head: order.index(head[0]) if head[0] in order else len(order),
        )])

        http_client.HTTPConnection._send_request(self, method, url, body, headers, *args, **kwargs)
