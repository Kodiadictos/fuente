# -*- coding: utf-8 -*-
import struct

from core.http.dns import Resolve
from core.libs import *
from .HTTPHandler import HTTPConnection, HTTPHandler
from ...proxytools import validate_ip


class ProxyHTTPHandler(HTTPHandler):
    """
    ProxyHTTPHandler para poder usar servidores proxy Socks4, Socks4A, Socks5
    """
    handler_order = 100

    def __init__(self, proxy, version):
        HTTPHandler.__init__(self, 0)
        self.proxy = proxy
        self.version = version

    def http_open(self, req):
        req._tunnel_host = req.host
        req.host = self.proxy
        return self.do_open(ProxyHTTPConnection, req, version=self.version)


class ProxyHTTPConnection(HTTPConnection):
    def __init__(self, *args, **kwargs):
        self.version = kwargs.pop('version')
        HTTPConnection.__init__(self, *args, **kwargs)

    @property
    def _tunnel_ip(self):
        ip = self._tunnel_host.split('.')
        return reduce(lambda a, b: int(a) * 256 + int(b), ip)

    def _tunnel(self):
        self._tunnel_host, self._tunnel_port = self._get_hostport(self._tunnel_host, None)
        return getattr(self, '_socks%s_tunnel' % getattr(self, 'version'))()

    def _authenticate(self):
        assert self.version == '5'

        auth_methods = [
            0  # NO AUTHENTICATION REQUIRED
        ]

        msg = struct.pack('!B', 5)  # Version
        msg += struct.pack('!B', len(auth_methods))  # lengh
        msg += ''.join(struct.pack('!B', m) for m in auth_methods)  # Auth methods

        self.send(msg)

        response = self.sock.recv(2)
        assert len(response) == 2

        method = struct.unpack('!B', response[1:2])[0]

        if method == 0:  # No authentication required
            pass
        else:
            raise NotImplementedError('Authentication not implemented')

    def _socks5_tunnel(self):
        self._authenticate()

        msg = struct.pack('!B', 5)  # Version
        msg += struct.pack('!B', 1)  # COMMAND: Connect
        msg += struct.pack('!B', 0)  # Reserved
        if not validate_ip(self._tunnel_host):
            msg += struct.pack('!B', 3)  # Type: 1-> IPv4, 3-> Domain, 4-> IPv6
            msg += struct.pack('!B', len(self._tunnel_host))  # Length Host
            msg += self._tunnel_host  # Host
        else:
            msg += struct.pack('!B', 1)  # Type: 1-> IPv4, 3-> Domain, 4-> IPv6
            msg += struct.pack('!I', self._tunnel_ip)  # Host
        msg += struct.pack('!H', self._tunnel_port)  # Port

        self.send(msg)

        response = self.sock.recv(10)
        cd = struct.unpack('!B', response[1:2])[0]

        if cd == 1:
            raise Exception('General SOCKS server failure')
        elif cd == 2:
            raise Exception('Connection not allowed by ruleset')
        elif cd == 3:
            raise Exception('Network unreachable')
        elif cd == 4:
            raise Exception('Host unreachable')
        elif cd == 5:
            raise Exception('Connection refused')
        elif cd == 6:
            raise Exception('TTL expired')
        elif cd == 7:
            raise Exception('Command not supported')
        elif cd == 8:
            raise Exception('Address type not supported')

    def _socks4_tunnel(self):
        if not validate_ip(self._tunnel_host):
            self._tunnel_host = Resolve(self._tunnel_host, True)[0]
        return self._socks4A_tunnel()

    def _socks4A_tunnel(self):
        msg = struct.pack('!B', 4)  # Version
        msg += struct.pack('!B', 1)  # COMMAND: Connect
        msg += struct.pack('!H', self._tunnel_port)  # Port
        if not validate_ip(self._tunnel_host):
            msg += struct.pack('!I', 1)  # Invalid IP
            msg += struct.pack('!B', 0)  # NULL
            msg += self._tunnel_host  # Host
            msg += struct.pack('!B', 0)  # NULL
        else:
            msg += struct.pack('!I', self._tunnel_ip)  # Host
            msg += struct.pack('!B', 0)  # NULL

        self.send(msg)

        response = self.sock.recv(8)
        cd = struct.unpack('!B', response[1:2])[0]

        if cd == 91:
            raise Exception("Request rejected or failed")
        elif cd == 92:
            raise Exception("Request rejected becasue SOCKS server cannot connect to identd on the client")
        elif cd == 93:
            raise Exception("Request rejected because the client program and identd report different user-ids")
