# -*- coding: utf-8 -*-
from six.moves import queue, urllib_request

from core.libs import *

proxies_fault = list()


def search_proxies(limit=None, test_url='https://cloudflare.com'):
    q = queue.Queue()
    ret = None
    threads = list()

    proxy_aut_list = settings.get_setting('proxy_aut_list', httptools.__file__) or "proxyscrape.com"
    dialog_background = set([a[1].split(os.sep)[-1][:-2] + a[3] for a in inspect.stack()[1:]]) & {
        'finder.channel_search',
        'newest.channel_search'}

    if dialog_background:
        dialog = platformtools.dialog_progress_bg('MediaExplorer: Buscando proxy', 'Iniciando búsqueda...')
        if not limit or limit > 30:
            limit = 30
    else:
        dialog = platformtools.dialog_progress('MediaExplorer: Buscando proxy', 'Iniciando búsqueda...')

    if proxy_aut_list == 'proxyscrape.com':
        resp = httptools.downloadpage(
            'https://api.proxyscrape.com/?request=displayproxies&proxytype=http&timeout=100')
        proxies = resp.data.split()

    elif proxy_aut_list == 'proxy-list.download':
        resp = httptools.downloadpage('https://www.proxy-list.download/api/v1/get?type=http')
        proxies = resp.data.split()

    else:  # settings.get_setting('proxy_aut_list', httptools.__file__) == 'spys.me'
        resp = httptools.downloadpage('http://spys.me/proxy.txt')
        proxies = scrapertools.find_multiple_matches(resp.data, r'(\d+\.\d+\.\d+\.\d+:\d+)')

    proxy_aut = settings.get_setting('proxy_aut', httptools.__file__)
    if proxy_aut:
        proxies_fault.append(proxy_aut)

    proxies = list(filter(lambda p: p not in proxies_fault, proxies))[:limit]

    for x in range(0, len(proxies), 10):
        if not ret:
            for proxy in proxies[x:x + 10]:
                t = Thread(target=test_proxy, args=(proxy, q, test_url))
                t.daemon = True
                t.start()
                threads.append(t)

                if not dialog_background and dialog.iscanceled():
                    dialog.close()
                    return ret

            dialog.update(int((x + 1) * 100 / len(proxies)),
                          'Buscando proxy en %s,\n'
                          'Comprobando proxy del %s al %s de %s' % (proxy_aut_list, x + 1, x + 10, len(proxies)))

            while [t for t in threads if t.isAlive()]:
                try:
                    ret = q.get(True, 1)
                    settings.set_setting('proxy_aut', ret, httptools.__file__)
                    break
                except queue.Empty:
                    if not dialog_background and dialog.iscanceled():
                        dialog.close()
                        return ret

    dialog.close()
    return ret


def test_proxy(proxy=True, q=None, test_url='https://cloudflare.com'):
    # Probamos el proxy con una url que sepamos que funciona
    ret = httptools.downloadpage(test_url, use_proxy=proxy, timeout=2, only_headers=True).sucess

    if isinstance(q, queue.Queue):
        if ret:
            logger.info('Multihilo: Proxy %s SI funciona' % proxy)
            q.put(proxy)
        else:
            logger.info('Multihilo: Proxy %s NO funciona' % proxy)
            proxies_fault.append(proxy)

    return ret


def retry_if_proxy_error(response, args):
    # Evitar comprobaciones recurrentes
    if 'test_proxy' in [a[3] for a in inspect.stack()[1:]]:
        return response

    if not response['sucess'] and settings.get_setting('proxy_tipo', httptools.__file__) == 2:
        logger.info('La petición no se ha realizado correctamtente, comprobando proxy...')
        if not settings.get_setting('proxy_aut', httptools.__file__) or not test_proxy():
            logger.info('El proxy actual no funciona: %s' % settings.get_setting('proxy_aut', httptools.__file__))
            if search_proxies(100):
                logger.info('Cambio de proxy automatico: %s' % settings.get_setting('proxy_aut', httptools.__file__))
                return httptools.downloadpage(**args).__dict__
            else:
                logger.info('No se ha encontrado ningun proxy que funcione')
        else:
            logger.info(
                'El proxy actual funciona correctamente: %s' % settings.get_setting('proxy_aut', httptools.__file__))

    return response


def retry_with_proxy_if_error(response, args):
    """
    Detecta si no se ha podido realizar correctamente la petición por causa de un bloqueo de operador, y en ese caso
    reintenta la coneión esta vez con proxy.
    :param response: respuesta de httptools.downloadpage
    :param args: argumenots originales de la petición a httptools.downloadpage
    :return: dict
    """
    # TODO: Por ahora solo se identifica si la petición se ha realizado con error, es posible (bastante probable) que
    #  algunos operadores no bloqueen la conexion sinó que modifiquen el contenido con un mensaje, en ese caso habria
    #  que detectar esos mensajes.

    # Solo usaremos proxy para llamadas que provienen de canales o servidores el resto de url van siempre sin proxy
    if not moduletools.call_from_channel() and not moduletools.call_from_server():
        return response

    if not response['sucess'] and not response['data'] and not response['headers'] and \
            settings.get_setting('proxy_mode', httptools.__file__) == 3:
        logger.debug('La petición no se ha realizado correctamtente, probando con proxy...')
        # Repetimos la petición con proxy
        args['use_proxy'] = True
        resp = httptools.downloadpage(**args).__dict__
        # Si el resultado es correcto, añadimos el dominio al listado de dominios que usan proxy
        # Este listado tiene una validez y pasado cierto tiempo se eliminan los registros
        if resp['sucess']:
            proxy_domains = settings.get_setting('proxy_domains', httptools.__file__) or {}
            domain = urllib_parse.urlparse(args['url'])[1]
            if domain not in proxy_domains:
                proxy_domains[domain] = time.time()
                settings.set_setting('proxy_domains', proxy_domains, httptools.__file__)
            return resp
    return response


def check_if_use_proxy(use_proxy, domain):
    """
    Comprueba si se ha de usar el proxy en función de los ajustes, el valor use_proxy puede ser un proxy forzado o un
    bool.
    :param use_proxy: bool/str
    :param domain: dominio
    :return: bool/str
    """
    # Solo usaremos proxy para llamadas que provienen de canales o servidores el resto de url van siempre sin proxy
    if not moduletools.call_from_channel() and not moduletools.call_from_server():
        return use_proxy

    if settings.get_setting('proxy_mode', httptools.__file__) == 2:  # Siempre
        if not use_proxy and 'search_proxies' not in [a[3] for a in inspect.stack()[1:]]:
            use_proxy = True

    elif settings.get_setting('proxy_mode', httptools.__file__) == 0:  # Nunca
        use_proxy = False

    elif settings.get_setting('proxy_mode', httptools.__file__) == 1:  # Solo modulos activados
        if not use_proxy:
            stack = inspect.stack()
            module = stack[2][1]
            use_proxy = is_proxy_enabled(module)
    elif settings.get_setting('proxy_mode', httptools.__file__) == 3:  # Autodetectar
        if not use_proxy:
            # Descartamos los regitros caducados
            proxy_domains = settings.get_setting('proxy_domains', httptools.__file__) or {}
            for dom, value in proxy_domains.copy().items():
                if time.time() - value > 60 * 60 * 24:
                    proxy_domains.pop(dom)
            settings.set_setting('proxy_domains', proxy_domains, httptools.__file__)

            # Comprobamos
            if domain in proxy_domains:
                use_proxy = True
            # En modo Automático se respeta la lista de canales/servidores de forma que se pueda forzar un canal
            # determinado y el resto solo se usara si falla sin proxy
            else:
                stack = inspect.stack()
                module = stack[2][1]
                use_proxy = is_proxy_enabled(module)

    return use_proxy


def is_proxy_enabled(module):
    """
    Comprueba si el modulo tiene el proxy activado en los ajustes
    :param module: path del modulo a comprobar
    :return: bool
    """
    module = "%s.json" % os.path.splitext(module)[0]
    params = moduletools.get_module_parameters(module)
    if not params:
        return False
    saved = settings.get_setting('proxy_modules', httptools.__file__) or {}
    return saved.get('/'.join(module.split(os.sep)[-2:]), params.get('proxy', False))


def validate_ip(value):
    """
    Comprueba si el valor correspone a una ip
    :param value: texto a validar
    :return: bool
    """
    if not len(scrapertools.find_single_match(value, r'^(\d*)\.(\d*)\.(\d*)\.(\d*)$')) == 4:
        return False
    for part in scrapertools.find_single_match(value, r'^(\d*)\.(\d*)\.(\d*)\.(\d*)$'):
        if int(part) > 255:
            return False
    return True


def validate_ip_port(value):
    """
    Comprueba si el valor correspone a una ip:puerto
    :param value: texto a validar
    :return: bool
    """
    if not validate_ip(value.split(":")[0]):
        return False

    if not len(value.split(':')) == 2 or int(scrapertools.find_single_match(value.split(':')[1], r'^(\d*)$')) > 65535:
        return False

    return True


def get_webproxy_services():
    """
    Obtiene el listado de Web-Proxy disponibles, para la sección ajustes
    :return: list
    """
    names = []
    for service in os.listdir(os.path.join(os.path.dirname(__file__), 'http', 'webproxy')):
        if not service.endswith('.py'):
            continue
        service = os.path.splitext(service)[0]
        if service == '__init__':
            continue
        klass = __import__('core.http.webproxy.%s' % service,
                           fromlist=['core.http.webproxy.%s' % service]).HTTPConnection
        names.append(klass.name)
    return names


def get_webproxy_service(name=None):
    """
    Obtiene el servicio Web-Proxy que se llame igual que el nombre pasado como parametro, si no se pasa ninguno devuelve
    el servición configurado en los ajustes.
     - En caso de no encontrase el servicio (si se ha indicado el nombre como parametro) devuelve el servicio
       configurado en los ajustes, si este tampoco se encuentra devuelve el servició por defecto
    :param name: nombre del sericio
    :return: list
    """
    srv = name or settings.get_setting('webproxy', httptools.__file__)
    for service in os.listdir(os.path.join(os.path.dirname(__file__), 'http', 'webproxy')):
        if not service.endswith('.py'):
            continue
        service = os.path.splitext(service)[0]
        if service == '__init__':
            continue
        klass = __import__('core.http.webproxy.%s' % service,
                           fromlist=['core.http.webproxy.%s' % service]).HTTPConnection
        if klass.name == srv:
            return [WebProxyHTTPHandler(klass), WebProxyHTTPSHandler(klass)]

    logger.debug('Servicio %s no encotrado' % srv)
    # Si se havia especificado el servicio, vuelve a probar por con el servicio guardado en settings
    if name:
        return get_webproxy_service()
    # Si el serviciouardado en settings y no existe, se elimina el setting para que pruebe con el servicio por defecto
    else:
        settings.pop_setting('webproxy', httptools.__file__)
        return get_webproxy_service()


def get_proxy_handler(proxy, proxy_type):
    """
    Devuelve el handler adecuado en función del tipo de proxy solicitado:
     - Proxy HTTP/HTTPS: utiliza el handler interno de python
     - Proxy Socks4, Socks 4A, Socks5: utiliza el handler propio para esos tipos de proxy
    :param proxy: Proxy (ip:puerto)
    :param proxy_type: Tipo de proxy: 0->HTTP/HTTPS, 1->Socks4, 2->Socks4A, 3->Socks5
    :return: list
    """
    if proxy_type > 0:
        if proxy_type == 1:
            version = '4'
        elif proxy_type == 2:
            version = '4A'
        else:
            version = '5'
        return [ProxyHTTPHandler(proxy, version), ProxyHTTPSHandler(proxy, version)]
    else:
        return [urllib_request.ProxyHandler({'http': proxy, 'https': proxy})]


def get_default_handlers(proxy):
    """
    Obtiene los handlers HTTP y HTTPS en función de si se usa proxy o no y del tipo de proxy
    :param proxy: Proxy bool/str
    :return: list
    """
    handlers = list()

    # Usaremos proxy
    if proxy:
        # Proxy actual para modo automatico
        proxy_aut = settings.get_setting('proxy_aut', httptools.__file__)
        # Proxy actual para modo manual
        proxy_man = settings.get_setting('proxy_man', httptools.__file__)
        # Proxy actual para Web-Proxy
        webproxy = settings.get_setting('webproxy', httptools.__file__)

        # Proxy forzado:
        if isinstance(proxy, str):
            # El parametro proxy contiene una IP
            if validate_ip_port(proxy):
                # uso del proxy forzado
                logger.info('Usando proxy forzado: %s' % proxy)
                handlers.extend(get_proxy_handler(proxy, 0))

            # El parametro proxy contiene el nombre de un servicio Web-Proxy
            else:
                # uso del web proxy forzado
                logger.info('Usando web proxy forzado: %s' % proxy)
                handlers.extend(get_webproxy_service(proxy))

        # El paremetro proxy es True
        else:
            # Proxy manual
            if settings.get_setting('proxy_tipo', httptools.__file__) == 1:
                # seleccion del proxy manual
                logger.info('Usando proxy manual: %s' % proxy_man)
                handlers.extend(get_proxy_handler(
                    proxy_man,
                    settings.get_setting('proxy_man_type', httptools.__file__))
                )

            # Proxy automatico
            elif settings.get_setting('proxy_tipo', httptools.__file__) == 2:
                # Proxy automatico guardado
                if proxy_aut:
                    # seleccion del proxy automatica: prefijado
                    logger.info('Usando proxy automático: %s' % proxy_aut)
                    handlers.extend(get_proxy_handler(proxy_aut, 0))

                # Proxy automatico no guardado
                else:
                    # seleccion del proxy automatica: busqueda
                    proxy_aut = proxytools.search_proxies()
                    if proxy_aut:
                        logger.info('Usando proxy autómatico: %s' % proxy_aut)
                        handlers.extend(get_proxy_handler(proxy_aut, 0))
                    else:
                        handlers.extend([HTTPHandler(), HTTPSHandler()])
                        proxy = False

            # Web Proxy
            elif settings.get_setting('proxy_tipo', httptools.__file__) == 0:
                logger.info('Usando web proxy: %s' % webproxy)
                handlers.extend(get_webproxy_service())

    # No usaremos proxy
    else:
        handlers.extend([HTTPHandler(), HTTPSHandler()])

    return handlers, proxy
