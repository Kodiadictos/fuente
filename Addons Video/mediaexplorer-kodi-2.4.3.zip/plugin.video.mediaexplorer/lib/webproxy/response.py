from email.parser import Parser
import json

from six.moves import http_client


class HTTPResponse:
    def __init__(self, connection):
        self._connection = connection
        self._response = json.loads(self._connection.proxy_response.read())
        self.reason = self._response['StatusDescription']
        self.code = int(self._response['StatusCode'])

    def info(self):
        return Parser(_class=http_client.HTTPMessage).parsestr(self._response.get('Headers'))

    def read(self):
        return self._response['Content']

    @property
    def headers(self):
        return self.info()

    def geturl(self):
        if self._response['Redirects']:
            return self._response['Redirects'][-1].split(' ')[1]
        else:
            return self._connection.url
