# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    if "File you are looking for is not found" in data:
        return ResolveError(0)

    # Obtenemos la url
    url = urllib_parse.urljoin(item.url, scrapertools.find_single_match(data, r"'(/pass[^']+)'"))
    video_url = httptools.downloadpage(url, headers={"referer": item.url}).data

    itemlist.append(Video(
        url=video_url + "?token=%s" % url.split('/')[-1],
        headers={
            'Referer': item.url
        }
    ))

    return itemlist
