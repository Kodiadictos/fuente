# -*- coding: utf-8 -*-
# Sistema
import sys
import os
import re
import time
import datetime
from threading import Lock, RLock
from threading import Thread as _Thread


class ResolveProgress:
    messages = {
        0: 'Descargando datos...',
        1: 'Obteniendo enlaces...',
        2: 'Desencriptando enlaces...',
        3: 'Desempaquetando javascript...',
        4: 'Resolviendo captcha...'
    }

    def __init__(self, completed, message):
        if isinstance(message, int):
            self.message = self.messages.get(message, '')
        else:
            self.message = message
        self.completed = completed

    def __repr__(self):
        return 'ResolveProgress(%d, %s)' % (self.completed, self.message)


class ResolveError(Exception):
    messages = {
        0: 'El archivo no existe o ha sido eliminado.',
        1: 'El archivo está siendo procesado.',
        2: 'Es necesaria una cuenta premium para poder reproducir el vídeo.',
        3: 'Es necesario el uso de un debrider con este servidor.',
        4: 'Sobrepasado el límite de visualizaciones.',
        5: 'El vídeo no tiene un formato compatible.',
        6: 'No se ha encontrado ninguna url válida.',
        7: 'El captcha es incorrecto.'
    }

    def __init__(self, code):
        if isinstance(code, int):
            Exception.__init__(self, self.messages[code])
            self.code = code
        else:
            Exception.__init__(self, code)
            self.code = None

    def __repr__(self):
        return self.args[0]


def change_units(value):
    import math
    units = ["B", "KB", "MB", "GB"]
    if value <= 0:
        return "%.2f %s" % (0, units[0])
    else:
        return "%.2f %s" % (value / 1024.0 ** int(math.log(value, 1024)), units[int(math.log(value, 1024))])

class Thread(_Thread):
    def __stop(self):
        try:
            logger.logger_object.end_thread()
        finally:
            _Thread.__stop(self)


# MediaExplorer
from platformcode import platformsettings


class SysInfo():
    def __init__(self):
        self.runtime_path = platformsettings.runtime_path
        self.data_path = platformsettings.data_path
        self.temp_path = platformsettings.temp_path
        self.bookmarks_path = platformsettings.bookmarks_path
        self.os = sys.platform
        self.platform_name = platformsettings.platform_name
        self.platform_version = platformsettings.platform_version
        self.main_version = platformsettings.main_version
        self.py_version = '%d.%d.%d' % sys.version_info[0:3]
        self.profile = {}


def call_api(path, data=None):
    import random
    uuid = settings.get_setting('installation_id')
    if not uuid:
        settings.set_setting('installation_id', "%032x" % (random.getrandbits(128)))
        uuid = settings.get_setting('installation_id')

    if data is None:
        data = {'uid': uuid}
    else:
        data['uid'] = uuid
    return httptools.downloadpage(
        'http://api%d.mediaexplorer.tk/v1/%s%s' % (
            random.randint(0, 5),
            path,
            '?' + urllib_parse.urlencode(data) if data else ''
        ))


sysinfo = SysInfo()
sys.path.append(os.path.join(sysinfo.runtime_path, 'lib'))
sys.path.append(os.path.join(sysinfo.data_path, 'modules', 'lib'))
sys.path.append(os.path.join(sysinfo.data_path, 'modules'))

from six.moves import urllib_parse
from six.moves import reload_module
from six.moves import reduce
import six
from core import servertools
from core import settings
from core import logger
from core import jsontools
from core import moduletools
from core import scrapertools
from core import filetools
from core.item import *
from platformcode import platformtools
from core import httptools
from core.mediainfo import MediaInfo
from core import mediainfo
from core import bbdd

# Reloads
reload_module(logger)
reload_module(settings)
reload_module(platformsettings)
reload_module(platformtools)
reload_module(jsontools)
reload_module(servertools)
reload_module(moduletools)
reload_module(httptools)
reload_module(scrapertools)
reload_module(filetools)
reload_module(bbdd)

# Inits
logger.init_logger()
settings.check_directories()
httptools.load_cookies()
sysinfo.profile = platformtools.get_profile()[1]
bbdd.create()
