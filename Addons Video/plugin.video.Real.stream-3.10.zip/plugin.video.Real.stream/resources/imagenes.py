import sys, re, os, unicodedata, xbmc, xbmcgui, xbmcplugin, xbmcaddon

# Menu Categorias:

extended = "https://imgur.com/dZyjocy"
buscar = "https://imgur.com/nZcJmXn"
pair = "https://imgur.com/jKnDMlt"
theMovieDB = "https://imgur.com/dZyjocy"
novedades = "https://imgur.com/GVMsDlk"
estrenos = "https://imgur.com/iM9hY3c"
recomendadas = "https://imgur.com/Jugkekb"
animacion = "https://imgur.com/D5B1ilU"
clasico = "https://imgur.com/9IxjIoh"
filmoteca = "https://imgur.com/JWDirtu"
familiar = "https://imgur.com/Pzm5hP2"
buscarseries = "https://imgur.com/HaLPj1O"
seriestodas = "https://imgur.com/xNmhb3A"
favorites = "https://imgur.com/NeMqZgp"
emision = "https://imgur.com/CHq7MHw"
mejores = "https://imgur.com/8HoOXn2"
seriesreto = "https://imgur.com/RTF3Ose"
seriesinfantiles = "https://imgur.com/lCm1IDE"

# Menu:
Mb_peliculas = "https://imgur.com/tadlbp4"
Mb_series = "https://imgur.com/HaLPj1O"
nuevos_no = "https://imgur.com/ucHUqBS"
nuevos_si = "https://imgur.com/thJxCCG"
menu_pelis = "https://imgur.com/lMduZJ7"
menu_series = "https://i.imgur.com/kVU51mK.png"
ajustes = "https://i.imgur.com/JwjQ4Ay.png"
favicon = "https://imgur.com/NeMqZgp"
resolver = "https://i.imgur.com/JwjQ4Ay.png"
test = "https://i.imgur.com/1GwvKOK.png"
videotutoriales = "https://i.imgur.com/K5AM3V6.png"
proxys = "https://i.imgur.com/JRTJDlM.png"


""" IMAGENES 
fanart = xbmc.translatePath(os.path.join(home, 'fanart.png'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
extended = xbmc.translatePath(os.path.join(home, 'extended_info.png'))
buscar = xbmc.translatePath(os.path.join(home, 'buscar.png'))
pair = xbmc.translatePath(os.path.join(home, 'pair.png'))
theMovieDB = xbmc.translatePath(os.path.join(home, 'theMovieDB.png'))
novedades = xbmc.translatePath(os.path.join(home, 'novedades.png'))
estrenos = xbmc.translatePath(os.path.join(home, 'estrenos.png'))
recomendadas = xbmc.translatePath(os.path.join(home, 'recomendadas.png'))
p_accion = xbmc.translatePath(os.path.join(home, 'accion.png'))
animacion = xbmc.translatePath(os.path.join(home, 'animacion.png'))
aventuras = xbmc.translatePath(os.path.join(home, 'aventuras.png'))
belico = xbmc.translatePath(os.path.join(home, 'belico.png'))
cifi = xbmc.translatePath(os.path.join(home, 'ciencia-ficcion.png'))
clasico = xbmc.translatePath(os.path.join(home, 'clasicos.png'))
filmoteca = xbmc.translatePath(os.path.join(home, 'filmoteca.png'))
comedia = xbmc.translatePath(os.path.join(home, 'comedia.png'))
crimen = xbmc.translatePath(os.path.join(home, 'crimen.png'))
drama = xbmc.translatePath(os.path.join(home, 'drama.png'))
familiar = xbmc.translatePath(os.path.join(home, 'familiar.png'))
fantasia = xbmc.translatePath(os.path.join(home, 'fantasia.png'))
historia = xbmc.translatePath(os.path.join(home, 'historia.png'))
superheroes = xbmc.translatePath(os.path.join(home, 'marvel.png'))
misterio = xbmc.translatePath(os.path.join(home, 'misterio.png'))
musical = xbmc.translatePath(os.path.join(home, 'musical.png'))
romance = xbmc.translatePath(os.path.join(home, 'romance.png'))
spain = xbmc.translatePath(os.path.join(home, 'spain.png'))
suspense = xbmc.translatePath(os.path.join(home, 'suspense.png'))
terror = xbmc.translatePath(os.path.join(home, 'terror.png'))
thriller = xbmc.translatePath(os.path.join(home, 'thriller.png'))
western = xbmc.translatePath(os.path.join(home, 'western.png'))
sagas = xbmc.translatePath(os.path.join(home, 'sagas_cine.png'))
calidad4k = xbmc.translatePath(os.path.join(home, '4k.png'))
torrent = xbmc.translatePath(os.path.join(home, 'torrent.png'))
buscarseries = xbmc.translatePath(os.path.join(home, 'buscar-serie.png'))
seriestodas = xbmc.translatePath(os.path.join(home, 'series-todas.png'))
favorites = xbmc.translatePath(os.path.join(home, 'favorites.png'))
artesmarciales = xbmc.translatePath(os.path.join(home, 'artesmarciales.png'))
emision = xbmc.translatePath(os.path.join(home, 'emision.png'))
mejores = xbmc.translatePath(os.path.join(home, 'mejores.png'))
seriesreto = xbmc.translatePath(os.path.join(home, 'seriesretro.png'))
Mb_peliculas = xbmc.translatePath(os.path.join(home, 'BuscadorPeliculas.png'))
Mb_series = xbmc.translatePath(os.path.join(home, 'BuscadorSeries.png'))
nuevos_no = xbmc.translatePath(os.path.join(home, 'Novedades_series.png'))
nuevos_si = xbmc.translatePath(os.path.join(home, 'Novedades_Episodios.png'))
seriesinfantiles = xbmc.translatePath(os.path.join(home, 'Seriesinfantiles.png'))
	

#Menus:

menu_pelis = xbmc.translatePath(os.path.join(home, 'peliculas.png'))
menu_series = xbmc.translatePath(os.path.join(home, 'series.png'))
ajustes = xbmc.translatePath(os.path.join(home, 'ajustes.png'))
vid = xbmc.translatePath(os.path.join(home, 'videoteca.png'))
favicon = xbmc.translatePath(os.path.join(home, 'favorites.png'))
resolver = xbmc.translatePath(os.path.join(home, 'resolver.png'))
test = xbmc.translatePath(os.path.join(home, 'test.png'))
videotutoriales = xbmc.translatePath(os.path.join(home, 'video-tutoriales.png'))
proxys = xbmc.translatePath(os.path.join(home, 'proxy.png'))

"""

