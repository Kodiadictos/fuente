# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Linker de las webs Porno Rusa http://tuchkatv.ru/18 by Bad-Max
# Version 0.0.1 (02.02.2018)
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)

import os
import sys
import urllib
import urllib2
import re

import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import plugintools, requests

from __main__ import *

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

version = "(v0.0.1)"

mi_data = xbmc.translatePath(os.path.join('special://home/userdata/addon_data/plugin.video.ayayay/'))
playlists = mi_data
temp = mi_data

if not os.path.exists(mi_data):
	os.makedirs(mi_data)  # Si no existe el directorio, lo creo


parser = "        [COLOR lime][B]AyAyAy!!! v0.0.1      [COLOR red]····[COLOR yellow]by Bad-Max[COLOR red]····[/B][/COLOR]"

url_ay = 'http://tuchkatv.ru/18/'
logo_ay = "https://i.imgur.com/FJnSJWb.png"
fondo_ay = "https://i.imgur.com/uOm1ttP.png"





# Entry point
def run():
	plugintools.log('[%s %s] Running %s... ' % (addonName, addonVersion, addonName))

	# Obteniendo parámetros...
	params = plugintools.get_params()
    
	
	if params.get("action") is None:
		main_list(params)
	else:
		action = params.get("action")
		exec action+"(params)"
	
	plugintools.close_item_list()            



# Main menu
def main_list(params):
	
	r = requests.get(url_ay)	
	data = r.content

	
	plugintools.add_item(action="",url="",title=parser,thumbnail=logo_ay,fanart=fondo_ay,folder=False,isPlayable=False)
	plugintools.add_item(action="",url="",title="",thumbnail=logo_ay,  fanart=fondo_ay, folder=False, isPlayable=False)
	
	canales = plugintools.find_single_match(data,'div class="body(.*?)class="rcol')
	cadacanal = plugintools.find_multiple_matches(canales,'<a href=(.*?)alt="')
	
	for item in cadacanal:
		link = plugintools.find_single_match(item,'"(.*?)"')
		titulo = plugintools.find_single_match(link,'/tuchkatv.ru/(.*?).html').replace("-" , " ").title()
		logo = plugintools.find_single_match(item,'src="(.*?)"')
		if len(logo) == 0:
			logo = logo_ay
		else:
			logo = "http://tuchkatv.ru" + logo
	
		plugintools.add_item(action="lanza_aces",url=link,title=titulo,thumbnail=logo,fanart=fondo_ay,folder=True,isPlayable=False)
		
	
	
	

def lanza_aces(params):
	fanart = params.get("fanart")
	thumbnail = params.get("thumbnail")
	url = params.get("url")
	titulo = params.get("title")

	r = requests.get(url)	
	data1 = r.content
	#plugintools.log("********************DATA1: "+data1+"***********************")	

	ace = plugintools.find_single_match(data1,'value="/player.php(.*?)"').replace("?id=" , "")

	url_montada = "plugin://program.plexus/?url=acestream%3A%2F%2F" + ace + "&mode=1&name=ID+de+Usuario+%28+acestream%3A%2F%2F63d893d4db0f0c591436c7a88b6f6fc27e84a5b8%29&iconimage=C%3A%5CUsers%5Cusuario%5CAppData%5CRoaming%5CKodi%5Caddons%5Cprogram.plexus%5Cresources%5Cart%5Cacestream-menu-item.png"
	
	plugintools.add_item(action="runPlugin",url=url_montada,title="Lanzar el Canal "+titulo,thumbnail=thumbnail,fanart=fanart,folder=False,isPlayable=True)
	


			
		
		
		
		
		
		
		
run()




	

