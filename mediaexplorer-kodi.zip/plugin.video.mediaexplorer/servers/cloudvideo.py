# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data

    url = scrapertools.find_single_match(data, '<source src="([^"]+)"')
    m3u8 = httptools.downloadpage(url).data
    patron = r'#EXT-X-STREAM-INF:.*?RESOLUTION=\d+x(\d+),.*?(http.*?)\n'

    for res, url in scrapertools.find_multiple_matches(m3u8, patron):
        itemlist.append(Video(url=url, res=res))

    return itemlist

