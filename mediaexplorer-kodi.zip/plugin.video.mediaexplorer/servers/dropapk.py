# -*- coding: utf-8 -*-
from core.libs import *


def get_video_url(item):
    logger.trace()
    itemlist = list()

    post = {
        'id': item.url.split('/')[-1],
        'op': 'download2',
        'referer': item.url,
        'method_free': 'Liberta+Descarga+>>',
        'method_premium': '',
        'adblock_detected': 0,

    }
    yield ResolveProgress(10, 0)

    data = httptools.downloadpage(item.url, post).data

    captcha = scrapertools.find_single_match(
        data,
        r'<td colspan=2><b>Entre cуdigo abajo:<\/b>.*?<img src="([^"]+)"\/>'
    )

    yield ResolveProgress(30, 4)

    if captcha:
        post['code'] = platformtools.show_captcha(captcha)
        post['rand'] = captcha.split('/')[-1].split('.')[0]

        yield ResolveProgress(50, 0)
        data = httptools.downloadpage(item.url, post).data

    yield ResolveProgress(80, 1)
    url = scrapertools.find_single_match(data, '<div class="download_box">.*?<a href="([^"]+)"')

    if url:
        itemlist.append(Video(url=url))

    yield itemlist
    return
