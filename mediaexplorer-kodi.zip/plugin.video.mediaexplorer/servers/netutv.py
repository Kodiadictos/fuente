# -*- coding: utf-8 -*-
from core.libs import *
import base64


def get_video_url(item):
    logger.trace()
    itemlist = []

    data = httptools.downloadpage(item.url).data
    videokey = scrapertools.find_single_match(data, "videokeyorig = '([^']+)'")
    userid = scrapertools.find_single_match(data, "userid = '([^']+)'")

    #test_captcha(item, videokey, userid)

    data = httptools.downloadpage(
        'https://hqq.tv/player/get_md5.php?v=%s' % videokey,
        headers={
            'Accept': '*/*',
        }).data

    json_data = jsontools.load_json(data)

    url = un(json_data['obf_link'])
    itemlist.append(Video(url=url, headers={'Accept': '*/*'}))

    return itemlist


def test_captcha(item, videokey, userid):
    if httptools.get_cookies('hqq.tv').get('gt'):
        return True
    else:
        httptools.downloadpage(
            'https://hqq.tv/ajax.php',
            headers={
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
            },
            post={
                'mode': 'increment_video',
                'videokey': videokey,
                'userid': userid,
                'ppref': six.ensure_text(base64.b64encode(six.ensure_binary(item.referer))),
                'gtoken': platformtools.show_recaptcha(item.url, '6Ldf5F0UAAAAALErn6bLEcv7JldhivPzb93Oy5t9', 'ad_watch')

            },
        )


def un(link):
    from six import unichr
    s2 = ''
    for i in range(1, len(link), 3):
        s2 += unichr(int(link[i:i + 3], 16))

    return 'https:' + s2 + '.mp4.m3u8'
