#############################################
# Addon Atlantis 2017
# Creado Por Netai - 
# Agradecer el soporte de Catoal y su ayuda.
# Peliculas y Series.
#############################################
import base64;exec base64.b64decode('')
